import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  // Note: Replace these with your actual Firebase config
  // Get your config from https://console.firebase.google.com/
  apiKey: "your-api-key",
  authDomain: "skillbridge-ai.firebaseapp.com",
  projectId: "skillbridge-ai",
  storageBucket: "skillbridge-ai.appspot.com",
  messagingSenderId: "123456789",
  appId: "your-app-id"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication and get a reference to the service
export const auth = getAuth(app);

// Initialize Cloud Firestore and get a reference to the service
export const db = getFirestore(app);

export default app;