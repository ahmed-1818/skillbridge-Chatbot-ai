import { useState } from 'react';
import { motion } from 'framer-motion';
import { LoginForm } from '@/components/auth/LoginForm';
import { SignupForm } from '@/components/auth/SignupForm';
import skillbridgeLogo from '@/assets/skillbridge-logo.png';

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="min-h-screen bg-gradient-chat flex items-center justify-center p-4">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-primary-glow/10 rounded-full blur-3xl"></div>
      </div>
      
      <div className="relative z-10 w-full max-w-md">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <img 
            src={skillbridgeLogo} 
            alt="SkillBridge AI" 
            className="w-48 h-12 mx-auto mb-4 object-contain"
          />
          <h1 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent mb-2">
            SkillBridge AI
          </h1>
          <p className="text-muted-foreground">
            AI-Powered Freelance Support Platform
          </p>
        </motion.div>

        {isLogin ? (
          <LoginForm 
            onToggleMode={() => setIsLogin(false)}
          />
        ) : (
          <SignupForm 
            onToggleMode={() => setIsLogin(true)}
          />
        )}
      </div>
    </div>
  );
}