import { useState } from 'react';
import { motion } from 'framer-motion';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/hooks/use-toast';
import { MessageSquare, Users, Filter, Search } from 'lucide-react';
import { SupportHeader } from '@/components/support/SupportHeader';
import { QueryCard } from '@/components/support/QueryCard';
import { FreelancerCard } from '@/components/support/FreelancerCard';
import { ProfileDialog } from '@/components/support/ProfileDialog';
import { QueryDialog } from '@/components/support/QueryDialog';

interface EscalatedQuery {
  id: string;
  userEmail: string;
  userName: string;
  query: string;
  timestamp: Date;
  status: 'pending' | 'assigned' | 'resolved';
  priority: 'low' | 'medium' | 'high';
}

interface Freelancer {
  id: string;
  name: string;
  avatar: string;
  skills: string[];
  rating: number;
  completedJobs: number;
  isOnline: boolean;
  hourlyRate: number;
  responseTime: string;
}

interface SupportDashboardProps {
  user: { email: string; name: string };
  onLogout: () => void;
}

// Mock data
const mockQueries: EscalatedQuery[] = [
  {
    id: '1',
    userEmail: 'john@example.com',
    userName: 'John Doe',
    query: 'I need help implementing authentication in React with TypeScript. The login form is not working properly and I keep getting CORS errors.',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
    status: 'pending',
    priority: 'high'
  },
  {
    id: '2',
    userEmail: 'sarah@example.com',
    userName: 'Sarah Smith',
    query: 'Can someone help me optimize my SQL queries? My database is running very slow and I think there might be indexing issues.',
    timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
    status: 'pending',
    priority: 'medium'
  },
  {
    id: '3',
    userEmail: 'mike@example.com',
    userName: 'Mike Johnson',
    query: 'I need assistance with setting up CI/CD pipeline using GitHub Actions for my Node.js application.',
    timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
    status: 'assigned',
    priority: 'medium'
  },
  {
    id: '4',
    userEmail: 'lisa@example.com',
    userName: 'Lisa Brown',
    query: 'Help needed with responsive design issues in my React app. Components are not displaying correctly on mobile devices.',
    timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000),
    status: 'pending',
    priority: 'low'
  }
];

const mockFreelancers: Freelancer[] = [
  {
    id: '1',
    name: 'Alex Chen',
    avatar: '/placeholder.svg',
    skills: ['React', 'TypeScript', 'Node.js', 'Authentication'],
    rating: 4.9,
    completedJobs: 127,
    isOnline: true,
    hourlyRate: 85,
    responseTime: '< 1 hour'
  },
  {
    id: '2',
    name: 'Maria Rodriguez',
    avatar: '/placeholder.svg',
    skills: ['SQL', 'Database Design', 'PostgreSQL', 'Optimization'],
    rating: 4.8,
    completedJobs: 89,
    isOnline: true,
    hourlyRate: 75,
    responseTime: '< 2 hours'
  },
  {
    id: '3',
    name: 'David Park',
    avatar: '/placeholder.svg',
    skills: ['DevOps', 'CI/CD', 'Docker', 'AWS', 'GitHub Actions'],
    rating: 4.7,
    completedJobs: 156,
    isOnline: false,
    hourlyRate: 95,
    responseTime: '< 4 hours'
  },
  {
    id: '4',
    name: 'Emma Thompson',
    avatar: '/placeholder.svg',
    skills: ['UI/UX', 'Responsive Design', 'CSS', 'React', 'Mobile-First'],
    rating: 4.9,
    completedJobs: 203,
    isOnline: true,
    hourlyRate: 70,
    responseTime: '< 30 min'
  }
];

export default function SupportDashboard({ user, onLogout }: SupportDashboardProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedQuery, setSelectedQuery] = useState<string | null>(null);
  const [bidStatus, setBidStatus] = useState<Record<string, string>>({});
  const [queries, setQueries] = useState<EscalatedQuery[]>(mockQueries);
  const [selectedFreelancer, setSelectedFreelancer] = useState<Freelancer | null>(null);
  const [selectedQueryDetails, setSelectedQueryDetails] = useState<EscalatedQuery | null>(null);

  const getPriorityColor = (priority: EscalatedQuery['priority']) => {
    switch (priority) {
      case 'high': return 'bg-destructive text-destructive-foreground';
      case 'medium': return 'bg-warning text-warning-foreground';
      case 'low': return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusColor = (status: EscalatedQuery['status']) => {
    switch (status) {
      case 'pending': return 'bg-warning text-warning-foreground';
      case 'assigned': return 'bg-primary text-primary-foreground';
      case 'resolved': return 'bg-success text-success-foreground';
    }
  };

  const handleBidToHelp = (queryId: string, freelancerId: string) => {
    setBidStatus(prev => ({
      ...prev,
      [`${queryId}-${freelancerId}`]: 'pending'
    }));
    
    const freelancer = mockFreelancers.find(f => f.id === freelancerId);
    const query = queries.find(q => q.id === queryId);
    
    toast({
      title: "Bid Submitted!",
      description: `${freelancer?.name} has been notified about "${query?.userName}'s" query.`,
    });
  };

  const handleAssignFreelancer = (queryId: string) => {
    setQueries(prev => prev.map(query => 
      query.id === queryId 
        ? { ...query, status: 'assigned' as const }
        : query
    ));
    
    toast({
      title: "Query Assigned!",
      description: "The query has been successfully assigned to a freelancer.",
    });
  };

  const handleViewProfile = (freelancer: Freelancer) => {
    setSelectedFreelancer(freelancer);
  };

  const handleViewDetails = (query: EscalatedQuery) => {
    setSelectedQueryDetails(query);
  };

  const filteredQueries = queries.filter(query =>
    query.query.toLowerCase().includes(searchTerm.toLowerCase()) ||
    query.userName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-chat">
      <SupportHeader user={user} onLogout={onLogout} />

      <div className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Escalated Queries Section */}
          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="space-y-4"
          >
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-foreground flex items-center">
                <MessageSquare className="h-5 w-5 mr-2" />
                Escalated Queries ({filteredQueries.length})
              </h2>
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search queries..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-64"
                  />
                </div>
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 mr-2" />
                  Filter
                </Button>
              </div>
            </div>

            <ScrollArea className="h-[600px]">
              <div className="space-y-4">
                {filteredQueries.map((query) => (
                  <QueryCard
                    key={query.id}
                    query={query}
                    selectedQuery={selectedQuery}
                    onViewDetails={handleViewDetails}
                    onAssignFreelancer={handleAssignFreelancer}
                    getPriorityColor={getPriorityColor}
                    getStatusColor={getStatusColor}
                  />
                ))}
              </div>
            </ScrollArea>
          </motion.div>

          {/* Available Freelancers Section */}
          <motion.div
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="space-y-4"
          >
            <h2 className="text-xl font-semibold text-foreground flex items-center">
              <Users className="h-5 w-5 mr-2" />
              Available Freelancers ({mockFreelancers.length})
            </h2>

            <ScrollArea className="h-[600px]">
              <div className="space-y-4">
                {mockFreelancers.map((freelancer) => (
                  <FreelancerCard
                    key={freelancer.id}
                    freelancer={freelancer}
                    selectedQuery={selectedQuery}
                    bidStatus={bidStatus}
                    onViewProfile={handleViewProfile}
                    onBidToHelp={handleBidToHelp}
                  />
                ))}
              </div>
            </ScrollArea>
          </motion.div>
        </div>
      </div>

      <ProfileDialog 
        selectedFreelancer={selectedFreelancer}
        onClose={() => setSelectedFreelancer(null)}
        onContactFreelancer={(freelancerId) => {
          handleBidToHelp('1', freelancerId);
          setSelectedFreelancer(null);
        }}
      />

      <QueryDialog 
        selectedQueryDetails={selectedQueryDetails}
        onClose={() => setSelectedQueryDetails(null)}
        onAssignFreelancer={handleAssignFreelancer}
        getPriorityColor={getPriorityColor}
        getStatusColor={getStatusColor}
      />
    </div>
  );
}