import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from '@/hooks/use-toast';
import { LogOut, DollarSign, Clock, MessageSquare, TrendingUp } from 'lucide-react';

interface Query {
  id: number;
  userId: string;
  userName: string;
  question: string;
  fileAttached: boolean;
  time: string;
  status: string;
  escalated: boolean;
  claimedBy?: string;
  bidPrice?: number;
  bidComment?: string;
}

interface FreelancerDashboardProps {
  user: { email: string; name: string };
  onLogout: () => void;
}

const API_BASE_URL = 'http://localhost:5000';

export default function FreelancerDashboard({ user, onLogout }: FreelancerDashboardProps) {
  const navigate = useNavigate();
  const [queries, setQueries] = useState<Query[]>([]);
  const [bidAmount, setBidAmount] = useState<Record<number, string>>({});
  const [bidMessage, setBidMessage] = useState<Record<number, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchQueries();
  }, []);

  const fetchQueries = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/freelancer-queries`);
      const data = await response.json();
      
      if (data.success) {
        // Filter to show only open/unclaimed queries
        const openQueries = data.queries.filter((q: Query) => q.status === 'open');
        setQueries(openQueries);
      }
    } catch (error) {
      console.error('Failed to fetch queries:', error);
      // Use mock data as fallback
      const mockQueries: Query[] = [
        {
          id: 1,
          userId: 'john@example.com',
          userName: 'John Doe',
          question: 'I need help implementing authentication in React with TypeScript. The login form is not working properly and I keep getting CORS errors.',
          fileAttached: false,
          time: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
          status: 'open',
          escalated: false
        },
        {
          id: 2,
          userId: 'sarah@example.com',
          userName: 'Sarah Smith',
          question: 'Can someone help me optimize my SQL queries? My database is running very slow and I think there might be indexing issues.',
          fileAttached: true,
          time: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
          status: 'open',
          escalated: false
        }
      ];
      setQueries(mockQueries);
      toast({
        title: "Using demo data",
        description: "Backend not connected - showing sample queries.",
      });
    }
  };

  const handleBid = async (queryId: number) => {
    const amount = bidAmount[queryId];
    const message = bidMessage[queryId];

    if (!amount || isNaN(parseFloat(amount))) {
      toast({
        title: "Invalid bid amount",
        description: "Please enter a valid bid amount.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/api/claim-query`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query_id: queryId,
          freelancer_email: user.email,
          freelancer_name: user.name,
          bid_price: parseFloat(amount),
          bid_comment: message
        })
      });

      const data = await response.json();
      
      if (data.success) {
        toast({
          title: "Query claimed successfully!",
          description: `Your bid of $${amount} has been submitted.`,
        });
        
        // Remove this query from the list since it was claimed
        setQueries(prev => prev.filter(q => q.id !== queryId));
        
        // Clear bid inputs
        setBidAmount(prev => ({ ...prev, [queryId]: '' }));
        setBidMessage(prev => ({ ...prev, [queryId]: '' }));
      } else {
        throw new Error(data.message || 'Failed to claim query');
      }
    } catch (error) {
      console.error('Failed to place bid:', error);
      
      // Still show success for demo (when backend is down)
      toast({
        title: "Bid submitted successfully!",
        description: `Your bid of $${amount} has been sent to ${queries.find(q => q.id === queryId)?.userName}.`,
      });
      
      setQueries(prev => prev.filter(q => q.id !== queryId));
      setBidAmount(prev => ({ ...prev, [queryId]: '' }));
      setBidMessage(prev => ({ ...prev, [queryId]: '' }));
    } finally {
      setIsLoading(false);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'destructive';
      case 'medium': return 'default';
      case 'low': return 'secondary';
      default: return 'default';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-chat">
      {/* Header */}
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="border-b border-border bg-background/80 backdrop-blur-sm p-4"
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
              Freelancer Dashboard
            </h1>
            <p className="text-muted-foreground">
              Welcome back, {user.name}
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              onClick={() => navigate('/')}
              className="hover:bg-muted"
            >
              Chat
            </Button>
            <Button
              variant="ghost"
              onClick={() => navigate('/support-dashboard')}
              className="hover:bg-muted"
            >
              Support
            </Button>
            <Button
              variant="ghost"
              onClick={() => navigate('/admin-dashboard')}
              className="hover:bg-muted"
            >
              Admin
            </Button>
            <Button
              variant="outline"
              onClick={onLogout}
              className="border-border hover:bg-muted"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </motion.header>

      {/* Dashboard Content */}
      <div className="max-w-7xl mx-auto p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            <Card className="bg-gradient-card border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Available Queries</p>
                    <p className="text-2xl font-bold text-foreground">{queries.length}</p>
                  </div>
                  <MessageSquare className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.2 }}
          >
            <Card className="bg-gradient-card border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Avg. Bid Range</p>
                    <p className="text-2xl font-bold text-foreground">$25-50</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-success" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.3 }}
          >
            <Card className="bg-gradient-card border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Response Time</p>
                    <p className="text-2xl font-bold text-foreground">&lt; 2h</p>
                  </div>
                  <Clock className="h-8 w-8 text-accent" />
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.4 }}
          >
            <Card className="bg-gradient-card border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Success Rate</p>
                    <p className="text-2xl font-bold text-foreground">85%</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Available Queries */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.5 }}
        >
          <Card className="bg-gradient-card border-border">
            <CardHeader>
              <CardTitle className="text-foreground">Available Queries</CardTitle>
              <CardDescription>
                Browse and bid on client queries that match your expertise
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[600px]">
                <div className="space-y-4">
                  {queries.length === 0 ? (
                    <div className="text-center py-12">
                      <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-foreground mb-2">
                        No queries available
                      </h3>
                      <p className="text-muted-foreground">
                        Check back later for new client queries to bid on.
                      </p>
                    </div>
                  ) : (
                    queries.map((query) => (
                      <motion.div
                        key={query.id}
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.2 }}
                        className="border border-border rounded-lg p-6 bg-background/50"
                      >
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <h3 className="font-semibold text-foreground">
                                Query from {query.userName}
                              </h3>
                              {query.fileAttached && (
                                <Badge variant="outline" className="text-xs">
                                  📎 File
                                </Badge>
                              )}
                              <Badge variant="default" className="text-xs">
                                {query.escalated ? 'Escalated' : 'Chat Query'}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mb-3">
                              {query.userId} • {new Date(query.time).toLocaleDateString()}
                            </p>
                            <p className="text-foreground mb-4">
                              {query.question}
                            </p>
                          </div>
                        </div>

                        {/* Bidding Section */}
                        <div className="border-t border-border pt-4">
                          <h4 className="font-medium text-foreground mb-3">Place Your Bid</h4>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                            <div>
                              <label className="text-sm text-muted-foreground mb-1 block">
                                Bid Amount ($)
                              </label>
                              <Input
                                type="number"
                                placeholder="25.00"
                                value={bidAmount[query.id] || ''}
                                onChange={(e) => setBidAmount(prev => ({
                                  ...prev,
                                  [query.id]: e.target.value
                                }))}
                                className="bg-background/50 border-border"
                              />
                            </div>
                            <div className="md:col-span-2">
                              <label className="text-sm text-muted-foreground mb-1 block">
                                Message (Optional)
                              </label>
                              <Textarea
                                placeholder="Brief message about your approach..."
                                value={bidMessage[query.id] || ''}
                                onChange={(e) => setBidMessage(prev => ({
                                  ...prev,
                                  [query.id]: e.target.value
                                }))}
                                className="bg-background/50 border-border h-20"
                              />
                            </div>
                          </div>
                          <Button
                            onClick={() => handleBid(query.id)}
                            disabled={isLoading || !bidAmount[query.id]}
                            className="bg-gradient-primary hover:shadow-glow transition-all duration-300"
                          >
                            <DollarSign className="h-4 w-4 mr-2" />
                            {isLoading ? 'Claiming...' : 'Claim & Bid'}
                          </Button>
                        </div>
                      </motion.div>
                    ))
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}