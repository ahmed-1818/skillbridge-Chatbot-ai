// This page is no longer used as the main entry point
// The App component now handles routing between Auth and Chat pages

const Index = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-chat">
      <div className="text-center">
        <h1 className="text-4xl font-bold bg-gradient-primary bg-clip-text text-transparent mb-4">
          SkillBridge
        </h1>
        <p className="text-xl text-muted-foreground">
          Redirecting to application...
        </p>
      </div>
    </div>
  );
};

export default Index;
