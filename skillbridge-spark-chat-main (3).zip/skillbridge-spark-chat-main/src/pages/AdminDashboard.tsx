import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from '@/hooks/use-toast';
import { 
  LogOut, 
  Users, 
  MessageSquare, 
  TrendingUp, 
  AlertTriangle,
  CheckCircle,
  Clock,
  Star
} from 'lucide-react';

interface Stats {
  total_chats: number;
  total_escalations: number;
  resolved_escalations: number;
  satisfaction_rate: number;
  total_users: number;
  total_freelancers: number;
}

interface Query {
  id: number;
  user_email: string;
  user_name: string;
  message: string;
  status: string;
  priority: string;
  assigned_freelancer?: string;
  created_at: string;
}

interface Freelancer {
  name: string;
  email: string;
  skills: string[];
  rating: number;
  completed_tasks: number;
  hourly_rate: number;
  bio: string;
}

interface AdminDashboardProps {
  user: { email: string; name: string };
  onLogout: () => void;
}

// Mock data for when backend is not available
const mockStats: Stats = {
  total_chats: 1247,
  total_escalations: 23,
  resolved_escalations: 18,
  satisfaction_rate: 94.2,
  total_users: 342,
  total_freelancers: 15
};

const mockQueries: Query[] = [
  {
    id: 1,
    user_email: 'john@example.com',
    user_name: 'John Doe',
    message: 'I need help implementing authentication in React with TypeScript. The login form is not working properly.',
    status: 'pending',
    priority: 'high',
    created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString()
  },
  {
    id: 2,
    user_email: 'sarah@example.com',
    user_name: 'Sarah Smith',
    message: 'Can someone help me optimize my SQL queries? My database is running very slow.',
    status: 'assigned',
    priority: 'medium',
    assigned_freelancer: 'Alex Chen',
    created_at: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString()
  }
];

const mockFreelancers: Freelancer[] = [
  {
    name: 'Alex Chen',
    email: 'alex@example.com',
    skills: ['React', 'TypeScript', 'Node.js', 'Authentication'],
    rating: 4.9,
    completed_tasks: 127,
    hourly_rate: 85,
    bio: 'Full-stack developer specializing in React and Node.js applications with 5+ years experience.'
  },
  {
    name: 'Maria Rodriguez',
    email: 'maria@example.com',
    skills: ['SQL', 'Database Design', 'PostgreSQL', 'Optimization'],
    rating: 4.8,
    completed_tasks: 89,
    hourly_rate: 75,
    bio: 'Database specialist with expertise in performance optimization and complex query design.'
  },
  {
    name: 'David Park',
    email: 'david@example.com',
    skills: ['DevOps', 'CI/CD', 'Docker', 'AWS'],
    rating: 4.7,
    completed_tasks: 156,
    hourly_rate: 95,
    bio: 'DevOps engineer focused on cloud infrastructure and automated deployment pipelines.'
  }
];

export default function AdminDashboard({ user, onLogout }: AdminDashboardProps) {
  const navigate = useNavigate();
  const [stats, setStats] = useState<Stats | null>(null);
  const [queries, setQueries] = useState<Query[]>([]);
  const [freelancers, setFreelancers] = useState<Freelancer[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      // Simulate loading and use mock data instead of API calls
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setStats(mockStats);
      setQueries(mockQueries);
      setFreelancers(mockFreelancers);
      
      toast({
        title: "Dashboard loaded successfully",
        description: "Showing demo data - backend not connected.",
      });
    } catch (error) {
      console.error('Failed to fetch data:', error);
      toast({
        title: "Failed to load dashboard data",
        description: "Please check your connection and try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAssignFreelancer = async (queryId: number, freelancerEmail: string) => {
    try {
      // Simulate assignment with mock behavior
      const freelancer = freelancers.find(f => f.email === freelancerEmail);
      
      setQueries(prev => prev.map(query => 
        query.id === queryId 
          ? { ...query, status: 'assigned', assigned_freelancer: freelancer?.name }
          : query
      ));

      toast({
        title: "Freelancer assigned successfully!",
        description: `Query assigned to ${freelancer?.name}.`,
      });
    } catch (error) {
      console.error('Failed to assign freelancer:', error);
      toast({
        title: "Failed to assign freelancer",
        description: "Please try again later.",
        variant: "destructive",
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'default';
      case 'assigned': return 'secondary';
      case 'resolved': return 'secondary';
      default: return 'default';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'destructive';
      case 'medium': return 'default';
      case 'low': return 'secondary';
      default: return 'default';
    }
  };

  if (isLoading && !stats) {
    return (
      <div className="min-h-screen bg-gradient-chat flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 bg-primary rounded-full animate-pulse mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-chat">
      {/* Header */}
      <motion.header
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.3 }}
        className="border-b border-border bg-background/80 backdrop-blur-sm p-4"
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
              Admin Dashboard
            </h1>
            <p className="text-muted-foreground">
              Platform overview and management
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              onClick={() => navigate('/')}
              className="hover:bg-muted"
            >
              Chat
            </Button>
            <Button
              variant="ghost"
              onClick={() => navigate('/support-dashboard')}
              className="hover:bg-muted"
            >
              Support
            </Button>
            <Button
              variant="ghost"
              onClick={() => navigate('/freelancer-dashboard')}
              className="hover:bg-muted"
            >
              Freelancer
            </Button>
            <Button
              variant="outline"
              onClick={onLogout}
              className="border-border hover:bg-muted"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </motion.header>

      <div className="max-w-7xl mx-auto p-6">
        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <Card className="bg-gradient-card border-border">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Chats</p>
                      <p className="text-2xl font-bold text-foreground">{stats.total_chats}</p>
                    </div>
                    <MessageSquare className="h-8 w-8 text-primary" />
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.2 }}
            >
              <Card className="bg-gradient-card border-border">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Escalations</p>
                      <p className="text-2xl font-bold text-foreground">{stats.total_escalations}</p>
                    </div>
                    <AlertTriangle className="h-8 w-8 text-warning" />
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.3 }}
            >
              <Card className="bg-gradient-card border-border">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Satisfaction</p>
                      <p className="text-2xl font-bold text-foreground">{stats.satisfaction_rate.toFixed(1)}%</p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-success" />
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.4 }}
            >
              <Card className="bg-gradient-card border-border">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Active Users</p>
                      <p className="text-2xl font-bold text-foreground">{stats.total_users}</p>
                    </div>
                    <Users className="h-8 w-8 text-accent" />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        )}

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.5 }}
        >
          <Tabs defaultValue="queries" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="queries">Escalated Queries</TabsTrigger>
              <TabsTrigger value="freelancers">Freelancers</TabsTrigger>
            </TabsList>

            <TabsContent value="queries">
              <Card className="bg-gradient-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground">Escalated Queries</CardTitle>
                  <CardDescription>
                    Manage and assign escalated queries to freelancers
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-[600px]">
                    <div className="space-y-4">
                      {queries.length === 0 ? (
                        <div className="text-center py-12">
                          <CheckCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                          <h3 className="text-lg font-medium text-foreground mb-2">
                            No escalated queries
                          </h3>
                          <p className="text-muted-foreground">
                            All queries are currently resolved or being handled.
                          </p>
                        </div>
                      ) : (
                        queries.map((query) => (
                          <motion.div
                            key={query.id}
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ duration: 0.2 }}
                            className="border border-border rounded-lg p-6 bg-background/50"
                          >
                            <div className="flex items-start justify-between mb-4">
                              <div className="flex-1">
                                <div className="flex items-center space-x-2 mb-2">
                                  <h3 className="font-semibold text-foreground">
                                    {query.user_name}
                                  </h3>
                                  <Badge variant={getStatusColor(query.status)}>
                                    {query.status}
                                  </Badge>
                                  <Badge variant={getPriorityColor(query.priority)}>
                                    {query.priority}
                                  </Badge>
                                </div>
                                <p className="text-sm text-muted-foreground mb-3">
                                  {query.user_email} • {new Date(query.created_at).toLocaleDateString()}
                                </p>
                                <p className="text-foreground mb-4">
                                  {query.message}
                                </p>
                                {query.assigned_freelancer && (
                                  <p className="text-sm text-muted-foreground">
                                    Assigned to: {query.assigned_freelancer}
                                  </p>
                                )}
                              </div>
                            </div>

                            {query.status === 'pending' && (
                              <div className="border-t border-border pt-4">
                                <h4 className="font-medium text-foreground mb-3">Assign to Freelancer</h4>
                                <div className="flex flex-wrap gap-2">
                                  {freelancers.slice(0, 3).map((freelancer) => (
                                    <Button
                                      key={freelancer.email}
                                      variant="outline"
                                      size="sm"
                                      onClick={() => handleAssignFreelancer(query.id, freelancer.email)}
                                      className="border-border hover:bg-muted"
                                    >
                                      {freelancer.name} ({freelancer.rating}★)
                                    </Button>
                                  ))}
                                </div>
                              </div>
                            )}
                          </motion.div>
                        ))
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="freelancers">
              <Card className="bg-gradient-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground">Freelancers</CardTitle>
                  <CardDescription>
                    View and manage registered freelancers
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {freelancers.map((freelancer) => (
                      <motion.div
                        key={freelancer.email}
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.2 }}
                        className="border border-border rounded-lg p-6 bg-background/50"
                      >
                        <div className="flex items-center space-x-3 mb-4">
                          <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center text-primary-foreground font-medium">
                            {freelancer.name.charAt(0)}
                          </div>
                          <div>
                            <h3 className="font-semibold text-foreground">{freelancer.name}</h3>
                            <div className="flex items-center space-x-1">
                              <Star className="h-4 w-4 text-warning fill-warning" />
                              <span className="text-sm text-muted-foreground">
                                {freelancer.rating} ({freelancer.completed_tasks} tasks)
                              </span>
                            </div>
                          </div>
                        </div>

                        <p className="text-sm text-muted-foreground mb-3">
                          {freelancer.bio}
                        </p>

                        <div className="flex flex-wrap gap-1 mb-3">
                          {freelancer.skills.map((skill) => (
                            <Badge key={skill} variant="secondary" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                        </div>

                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Rate:</span>
                          <span className="font-medium text-foreground">
                            ${freelancer.hourly_rate}/hr
                          </span>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}