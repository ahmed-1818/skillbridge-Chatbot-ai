import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { ChatSidebar } from '@/components/chat/ChatSidebar';
import { MobileChatHeader } from '@/components/chat/MobileChatHeader';
import { ChatMessage } from '@/components/chat/ChatMessage';
import { ChatInput } from '@/components/chat/ChatInput';
import { FeedbackButtons } from '@/components/chat/FeedbackButtons';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Users } from 'lucide-react';
import axios from 'axios';

interface Message {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: Date;
}

interface ChatHistory {
  id: string;
  title: string;
  timestamp: Date;
}

interface ChatProps {
  user: { email: string; name: string; uid: string };
  onLogout: () => void;
}

// Backend API endpoints - will connect to Python Flask backend
const API_BASE_URL = 'http://localhost:5000';
const CHAT_API_ENDPOINT = `${API_BASE_URL}/api/chat`;
const ESCALATE_API_ENDPOINT = `${API_BASE_URL}/api/escalate`;
const FEEDBACK_API_ENDPOINT = `${API_BASE_URL}/api/feedback`;

export default function Chat({ user, onLogout }: ChatProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [escalationCount, setEscalationCount] = useState(0);
  const [chatHistory, setChatHistory] = useState<ChatHistory[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Mock chat history data
  useEffect(() => {
    const mockHistory: ChatHistory[] = [
      {
        id: 'chat-1',
        title: 'JavaScript Fundamentals',
        timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
      },
      {
        id: 'chat-2',
        title: 'React Hooks Tutorial',
        timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000)
      },
      {
        id: 'chat-3',
        title: 'API Integration Help',
        timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000)
      }
    ];
    setChatHistory(mockHistory);
  }, []);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Initialize with welcome message
  useEffect(() => {
    if (messages.length === 0) {
      const welcomeMessage: Message = {
        id: 'welcome',
        content: `Hello ${user.name}! 👋 Welcome to SkillBridge AI! I'm your intelligent freelance support assistant. I can help you with:\n\n• Technical questions and problem-solving\n• Project guidance and best practices\n• Skill development and learning resources\n• Connecting you with expert freelancers when needed\n\nWhat can I help you with today?`,
        isUser: false,
        timestamp: new Date()
      };
      setMessages([welcomeMessage]);
    }
  }, [user.name, messages.length]);

  const handleSendMessage = async (content: string, file?: File) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      content: file ? `${content}\n\n📎 Attached: ${file.name}` : content,
      isUser: true,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      // Send message to Python backend
      const response = await axios.post(CHAT_API_ENDPOINT, {
        message: content,
        user_email: user.email,
        file_attached: !!file
      });

      if (response.data.success) {
        const botMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: response.data.response,
          isUser: false,
          timestamp: new Date()
        };

        setMessages(prev => [...prev, botMessage]);
      } else {
        throw new Error(response.data.message || 'Failed to get response');
      }

    } catch (error) {
      console.error('Failed to send message:', error);
      toast({
        title: "Message failed to send",
        description: "Please check your connection and try again.",
        variant: "destructive",
      });

      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: "I'm sorry, I'm having trouble connecting right now. Please try again in a moment.",
        isUser: false,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEscalate = async () => {
    try {
      setEscalationCount(prev => prev + 1);
      
      // Send escalation to Python backend
      const response = await axios.post(ESCALATE_API_ENDPOINT, {
        user_email: user.email,
        message: messages.length > 0 ? messages[messages.length - 1].content : 'User requested escalation'
      });

      if (response.data.success) {
        const escalationMessage: Message = {
          id: Date.now().toString(),
          content: response.data.message,
          isUser: false,
          timestamp: new Date()
        };

        setMessages(prev => [...prev, escalationMessage]);
      }

    } catch (error) {
      console.error('Failed to escalate:', error);
      toast({
        title: "Escalation failed",
        description: "Unable to connect to human support. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleFeedback = async (satisfied: boolean) => {
    try {
      // Send feedback to Python backend
      await axios.post(FEEDBACK_API_ENDPOINT, {
        user_email: user.email,
        satisfied
      });

      console.log('Feedback submitted:', { satisfied, user: user.email, timestamp: new Date() });
    } catch (error) {
      console.error('Failed to submit feedback:', error);
    }
  };

  const handleSelectChat = (chatId: string) => {
    if (chatId === 'new') {
      // Start new chat
      setMessages([]);
    } else {
      // Load selected chat (mock implementation)
      toast({
        title: "Chat loaded",
        description: "Previous conversation loaded successfully.",
      });
    }
  };

  return (
    <div className="flex h-screen bg-gradient-chat">
      {/* Desktop Sidebar */}
      <ChatSidebar
        user={user}
        onLogout={onLogout}
        chatHistory={chatHistory}
        onSelectChat={handleSelectChat}
        escalationCount={escalationCount}
      />

      <div className="flex-1 flex flex-col">
        {/* Mobile Header */}
        <MobileChatHeader
          user={user}
          onLogout={onLogout}
          chatHistory={chatHistory}
          onSelectChat={handleSelectChat}
          escalationCount={escalationCount}
        />
        {/* Desktop Chat Header */}
        <motion.header
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="hidden md:block border-b border-border bg-background/80 backdrop-blur-sm p-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold text-foreground">
                SkillBridge AI Assistant
              </h2>
              <p className="text-sm text-muted-foreground">
                Your intelligent freelance support companion
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-success rounded-full"></div>
              <span className="text-xs text-muted-foreground">Online</span>
            </div>
          </div>
        </motion.header>

        {/* Chat Messages */}
        <div className="flex-1 flex flex-col">
          <ScrollArea className="flex-1 p-4">
            <div className="max-w-4xl mx-auto">
              {messages.map((message, index) => (
                <ChatMessage
                  key={message.id}
                  message={message}
                  index={index}
                />
              ))}
              
              {isLoading && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex items-start space-x-4 mb-6"
                >
                  <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                    <div className="w-2 h-2 bg-muted-foreground rounded-full animate-pulse"></div>
                  </div>
                  <div className="bg-chat-bot text-chat-bot-foreground rounded-2xl px-4 py-3">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </motion.div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          {/* Feedback Section */}
          {messages.length > 1 && !isLoading && (
            <div className="px-4 max-w-4xl mx-auto w-full">
              <FeedbackButtons
                onFeedback={handleFeedback}
                disabled={isLoading}
              />
            </div>
          )}

          {/* Escalation Button */}
          <div className="px-4 max-w-4xl mx-auto w-full mb-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.location.href = '/support-dashboard'}
              className="w-full border-accent/50 hover:bg-accent/10"
            >
              <Users className="h-4 w-4 mr-2" />
              Need Human Help? Contact Support
            </Button>
          </div>

          {/* Chat Input */}
          <ChatInput
            onSendMessage={handleSendMessage}
            onEscalate={handleEscalate}
            isLoading={isLoading}
          />
        </div>
      </div>
    </div>
  );
}