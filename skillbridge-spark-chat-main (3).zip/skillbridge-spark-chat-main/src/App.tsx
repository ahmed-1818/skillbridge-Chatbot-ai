import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import Auth from "./pages/Auth";
import Chat from "./pages/Chat";
import SupportDashboard from "./pages/SupportDashboard";
import FreelancerDashboard from "./pages/FreelancerDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import skillbridgeLogo from "@/assets/skillbridge-logo.png";

const queryClient = new QueryClient();

const App = () => {
  const { user, loading, logout } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-chat flex items-center justify-center">
        <div className="text-center">
          <img 
            src={skillbridgeLogo} 
            alt="SkillBridge AI" 
            className="w-32 h-8 mx-auto mb-4 object-contain"
          />
          <div className="w-8 h-8 bg-primary rounded-full animate-pulse mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading SkillBridge AI...</p>
        </div>
      </div>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Router>
          <Toaster />
          <Sonner />
          <Routes>
            <Route 
              path="/" 
              element={
                user ? (
                  <Chat user={user} onLogout={logout} />
                ) : (
                  <Auth />
                )
              } 
            />
            <Route 
              path="/support-dashboard" 
              element={
                user ? (
                  <SupportDashboard user={user} onLogout={logout} />
                ) : (
                  <Navigate to="/" replace />
                )
              } 
            />
            <Route 
              path="/freelancer-dashboard" 
              element={
                user ? (
                  <FreelancerDashboard user={user} onLogout={logout} />
                ) : (
                  <Navigate to="/" replace />
                )
              } 
            />
            <Route 
              path="/admin-dashboard" 
              element={
                user ? (
                  <AdminDashboard user={user} onLogout={logout} />
                ) : (
                  <Navigate to="/" replace />
                )
              } 
            />
          </Routes>
        </Router>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
