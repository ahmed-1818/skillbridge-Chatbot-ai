import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, Mail } from 'lucide-react';

interface EscalatedQuery {
  id: string;
  userEmail: string;
  userName: string;
  query: string;
  timestamp: Date;
  status: 'pending' | 'assigned' | 'resolved';
  priority: 'low' | 'medium' | 'high';
}

interface QueryDialogProps {
  selectedQueryDetails: EscalatedQuery | null;
  onClose: () => void;
  onAssignFreelancer: (queryId: string) => void;
  getPriorityColor: (priority: EscalatedQuery['priority']) => string;
  getStatusColor: (status: EscalatedQuery['status']) => string;
}

export function QueryDialog({ 
  selectedQueryDetails, 
  onClose, 
  onAssignFreelancer, 
  getPriorityColor, 
  getStatusColor 
}: QueryDialogProps) {
  return (
    <Dialog open={!!selectedQueryDetails} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Query Details</DialogTitle>
        </DialogHeader>
        {selectedQueryDetails && (
          <div className="space-y-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center text-primary-foreground font-medium">
                  {selectedQueryDetails.userName.charAt(0)}
                </div>
                <div>
                  <h3 className="text-lg font-semibold">{selectedQueryDetails.userName}</h3>
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <Mail className="h-3 w-3" />
                    <span>{selectedQueryDetails.userEmail}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Badge className={getPriorityColor(selectedQueryDetails.priority)}>
                  {selectedQueryDetails.priority.toUpperCase()}
                </Badge>
                <Badge className={getStatusColor(selectedQueryDetails.status)}>
                  {selectedQueryDetails.status.toUpperCase()}
                </Badge>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center text-sm text-muted-foreground">
                <Clock className="h-4 w-4 mr-2" />
                <span>Submitted on {selectedQueryDetails.timestamp.toLocaleString()}</span>
              </div>

              <div>
                <h4 className="font-medium mb-2">Query Description</h4>
                <div className="bg-muted/50 p-4 rounded-lg">
                  <p className="text-sm leading-relaxed">{selectedQueryDetails.query}</p>
                </div>
              </div>
            </div>

            <div className="flex space-x-2 pt-4">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={onClose}
              >
                Close
              </Button>
              <Button 
                className="flex-1 bg-gradient-primary hover:shadow-glow"
                onClick={() => {
                  onAssignFreelancer(selectedQueryDetails.id);
                  onClose();
                }}
                disabled={selectedQueryDetails.status === 'assigned'}
              >
                {selectedQueryDetails.status === 'assigned' ? 'Already Assigned' : 'Assign Freelancer'}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}