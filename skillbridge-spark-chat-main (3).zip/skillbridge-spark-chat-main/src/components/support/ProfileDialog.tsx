import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { User, Clock, Star } from 'lucide-react';

interface Freelancer {
  id: string;
  name: string;
  avatar: string;
  skills: string[];
  rating: number;
  completedJobs: number;
  isOnline: boolean;
  hourlyRate: number;
  responseTime: string;
}

interface ProfileDialogProps {
  selectedFreelancer: Freelancer | null;
  onClose: () => void;
  onContactFreelancer: (freelancerId: string) => void;
}

export function ProfileDialog({ selectedFreelancer, onClose, onContactFreelancer }: ProfileDialogProps) {
  return (
    <Dialog open={!!selectedFreelancer} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Freelancer Profile</DialogTitle>
        </DialogHeader>
        {selectedFreelancer && (
          <div className="space-y-4">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Avatar className="w-16 h-16">
                  <AvatarImage src={selectedFreelancer.avatar} />
                  <AvatarFallback className="bg-gradient-primary text-primary-foreground text-lg">
                    {selectedFreelancer.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-background ${
                  selectedFreelancer.isOnline ? 'bg-success' : 'bg-muted'
                }`}></div>
              </div>
              <div>
                <h3 className="text-lg font-semibold">{selectedFreelancer.name}</h3>
                <div className="flex items-center space-x-2 text-sm">
                  <div className="flex items-center">
                    <Star className="h-4 w-4 fill-warning text-warning mr-1" />
                    <span className="font-medium">{selectedFreelancer.rating}</span>
                  </div>
                  <span className="text-muted-foreground">•</span>
                  <span className="text-muted-foreground">
                    {selectedFreelancer.completedJobs} jobs completed
                  </span>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center space-x-2 text-sm">
                <User className="h-4 w-4 text-muted-foreground" />
                <span>{selectedFreelancer.isOnline ? 'Available Now' : 'Offline'}</span>
                <Badge variant={selectedFreelancer.isOnline ? 'default' : 'secondary'} className="text-xs">
                  {selectedFreelancer.isOnline ? 'Online' : 'Offline'}
                </Badge>
              </div>
              
              <div className="flex items-center space-x-2 text-sm">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span>Responds in {selectedFreelancer.responseTime}</span>
              </div>

              <div className="text-right">
                <div className="text-2xl font-bold text-primary">
                  ${selectedFreelancer.hourlyRate}/hr
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium mb-2">Skills & Expertise</h4>
              <div className="flex flex-wrap gap-2">
                {selectedFreelancer.skills.map((skill) => (
                  <Badge key={skill} variant="secondary" className="text-xs">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="flex space-x-2 pt-4">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={onClose}
              >
                Close
              </Button>
              <Button 
                className="flex-1 bg-gradient-primary hover:shadow-glow"
                onClick={() => {
                  onContactFreelancer(selectedFreelancer.id);
                  onClose();
                }}
              >
                Contact Freelancer
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}