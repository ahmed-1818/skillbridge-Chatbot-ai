import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogTrigger } from '@/components/ui/dialog';
import { Star, CheckCircle2 } from 'lucide-react';

interface Freelancer {
  id: string;
  name: string;
  avatar: string;
  skills: string[];
  rating: number;
  completedJobs: number;
  isOnline: boolean;
  hourlyRate: number;
  responseTime: string;
}

interface FreelancerCardProps {
  freelancer: Freelancer;
  selectedQuery: string | null;
  bidStatus: Record<string, string>;
  onViewProfile: (freelancer: Freelancer) => void;
  onBidToHelp: (queryId: string, freelancerId: string) => void;
}

export function FreelancerCard({ 
  freelancer, 
  selectedQuery, 
  bidStatus, 
  onViewProfile, 
  onBidToHelp 
}: FreelancerCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
    >
      <Card className="hover:shadow-glow transition-all duration-200">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Avatar className="w-12 h-12">
                  <AvatarImage src={freelancer.avatar} />
                  <AvatarFallback className="bg-gradient-primary text-primary-foreground">
                    {freelancer.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-background ${
                  freelancer.isOnline ? 'bg-success' : 'bg-muted'
                }`}></div>
              </div>
              <div>
                <CardTitle className="text-base font-semibold">
                  {freelancer.name}
                </CardTitle>
                <div className="flex items-center space-x-2 text-sm">
                  <div className="flex items-center">
                    <Star className="h-3 w-3 fill-warning text-warning mr-1" />
                    <span className="font-medium">{freelancer.rating}</span>
                  </div>
                  <span className="text-muted-foreground">•</span>
                  <span className="text-muted-foreground">
                    {freelancer.completedJobs} jobs
                  </span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold text-primary">
                ${freelancer.hourlyRate}/hr
              </div>
              <div className="text-xs text-muted-foreground">
                Responds in {freelancer.responseTime}
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex flex-wrap gap-1">
              {freelancer.skills.slice(0, 4).map((skill) => (
                <Badge key={skill} variant="secondary" className="text-xs">
                  {skill}
                </Badge>
              ))}
              {freelancer.skills.length > 4 && (
                <Badge variant="secondary" className="text-xs">
                  +{freelancer.skills.length - 4} more
                </Badge>
              )}
            </div>
            
            <div className="flex items-center space-x-2">
              <Dialog>
                <DialogTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => onViewProfile(freelancer)}
                  >
                    View Profile
                  </Button>
                </DialogTrigger>
              </Dialog>
              <Button 
                size="sm" 
                className="flex-1 bg-gradient-primary hover:shadow-glow"
                onClick={() => onBidToHelp(selectedQuery || '1', freelancer.id)}
                disabled={bidStatus[`${selectedQuery || '1'}-${freelancer.id}`] === 'pending'}
              >
                {bidStatus[`${selectedQuery || '1'}-${freelancer.id}`] === 'pending' ? (
                  <>
                    <CheckCircle2 className="h-3 w-3 mr-1" />
                    Pending Review
                  </>
                ) : (
                  'Bid to Help'
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}