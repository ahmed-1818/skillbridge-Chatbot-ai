import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogTrigger } from '@/components/ui/dialog';
import { Clock } from 'lucide-react';

interface EscalatedQuery {
  id: string;
  userEmail: string;
  userName: string;
  query: string;
  timestamp: Date;
  status: 'pending' | 'assigned' | 'resolved';
  priority: 'low' | 'medium' | 'high';
}

interface QueryCardProps {
  query: EscalatedQuery;
  selectedQuery: string | null;
  onViewDetails: (query: EscalatedQuery) => void;
  onAssignFreelancer: (queryId: string) => void;
  getPriorityColor: (priority: EscalatedQuery['priority']) => string;
  getStatusColor: (status: EscalatedQuery['status']) => string;
}

export function QueryCard({ 
  query, 
  selectedQuery, 
  onViewDetails, 
  onAssignFreelancer, 
  getPriorityColor, 
  getStatusColor 
}: QueryCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      <Card className={`cursor-pointer transition-all duration-200 ${
        selectedQuery === query.id ? 'ring-2 ring-primary' : 'hover:shadow-glow'
      }`}>
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-primary rounded-full flex items-center justify-center text-primary-foreground font-medium text-sm">
                {query.userName.charAt(0)}
              </div>
              <div>
                <CardTitle className="text-sm font-medium">
                  {query.userName}
                </CardTitle>
                <p className="text-xs text-muted-foreground">
                  {query.userEmail}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge className={getPriorityColor(query.priority)}>
                {query.priority.toUpperCase()}
              </Badge>
              <Badge className={getStatusColor(query.status)}>
                {query.status.toUpperCase()}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-foreground mb-3 line-clamp-3">
            {query.query}
          </p>
          <div className="flex items-center justify-between">
            <div className="flex items-center text-xs text-muted-foreground">
              <Clock className="h-3 w-3 mr-1" />
              {query.timestamp.toLocaleString()}
            </div>
            <div className="flex items-center space-x-2">
              <Dialog>
                <DialogTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => onViewDetails(query)}
                  >
                    View Details
                  </Button>
                </DialogTrigger>
              </Dialog>
              <Button 
                size="sm"
                className="bg-gradient-primary hover:shadow-glow"
                onClick={() => onAssignFreelancer(query.id)}
                disabled={query.status === 'assigned'}
              >
                {query.status === 'assigned' ? 'Assigned' : 'Assign Freelancer'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}