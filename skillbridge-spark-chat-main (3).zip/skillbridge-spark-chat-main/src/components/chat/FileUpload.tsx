import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Upload, X, File } from 'lucide-react';

interface FileUploadProps {
  onFileSelect: (file: File | null) => void;
  selectedFile: File | null;
  disabled?: boolean;
}

export function FileUpload({ onFileSelect, selectedFile, disabled }: FileUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select a file smaller than 10MB.",
        variant: "destructive",
      });
      return;
    }

    // Check file type
    const allowedTypes = [
      'application/zip',
      'application/x-zip-compressed',
      'text/csv',
      'application/vnd.ms-excel',
      'image/jpeg',
      'image/png',
      'image/gif',
      'text/plain',
      'application/pdf'
    ];

    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Invalid file type",
        description: "Please select a ZIP, CSV, image, text, or PDF file.",
        variant: "destructive",
      });
      return;
    }

    onFileSelect(file);
  };

  const handleRemoveFile = () => {
    onFileSelect(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="flex items-center space-x-2">
      <input
        ref={fileInputRef}
        type="file"
        onChange={handleFileSelect}
        accept=".zip,.csv,.jpg,.jpeg,.png,.gif,.txt,.pdf"
        className="hidden"
        disabled={disabled}
      />
      
      {selectedFile ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex items-center space-x-2 bg-muted/50 rounded-lg px-3 py-2 max-w-48"
        >
          <File className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm text-foreground truncate">
            {selectedFile.name}
          </span>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleRemoveFile}
            className="h-5 w-5 p-0 hover:bg-destructive/20"
            disabled={disabled}
          >
            <X className="h-3 w-3" />
          </Button>
        </motion.div>
      ) : (
        <Button
          variant="outline"
          size="sm"
          onClick={() => fileInputRef.current?.click()}
          className="border-border hover:bg-muted"
          disabled={disabled}
        >
          <Upload className="h-4 w-4 mr-2" />
          Upload File
        </Button>
      )}
    </div>
  );
}