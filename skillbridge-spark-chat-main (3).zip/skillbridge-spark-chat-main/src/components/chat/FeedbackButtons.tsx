import { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ThumbsUp, ThumbsDown } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface FeedbackButtonsProps {
  onFeedback: (satisfied: boolean) => void;
  disabled?: boolean;
}

export function FeedbackButtons({ onFeedback, disabled }: FeedbackButtonsProps) {
  const [feedbackGiven, setFeedbackGiven] = useState<boolean | null>(null);
  const { toast } = useToast();

  const handleFeedback = (satisfied: boolean) => {
    setFeedbackGiven(satisfied);
    onFeedback(satisfied);
    
    toast({
      title: satisfied ? "Thank you for your feedback!" : "We'll do better next time",
      description: satisfied 
        ? "We're glad we could help you today." 
        : "Your feedback helps us improve our service.",
      className: satisfied ? "bg-success text-success-foreground" : "bg-warning text-warning-foreground",
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="mt-6"
    >
      <Card className="bg-background/50 border-border">
        <CardContent className="p-4">
          <div className="text-center">
            <h3 className="text-sm font-medium text-foreground mb-3">
              How was your experience today?
            </h3>
            
            <div className="flex justify-center space-x-4">
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  variant={feedbackGiven === true ? "default" : "outline"}
                  size="lg"
                  onClick={() => handleFeedback(true)}
                  disabled={disabled || feedbackGiven !== null}
                  className={`${
                    feedbackGiven === true 
                      ? 'bg-success hover:bg-success/90 text-success-foreground' 
                      : 'border-success/50 text-success hover:bg-success/10'
                  } transition-all duration-300`}
                >
                  <ThumbsUp className="h-5 w-5 mr-2" />
                  Satisfied
                </Button>
              </motion.div>
              
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  variant={feedbackGiven === false ? "default" : "outline"}
                  size="lg"
                  onClick={() => handleFeedback(false)}
                  disabled={disabled || feedbackGiven !== null}
                  className={`${
                    feedbackGiven === false 
                      ? 'bg-warning hover:bg-warning/90 text-warning-foreground' 
                      : 'border-warning/50 text-warning hover:bg-warning/10'
                  } transition-all duration-300`}
                >
                  <ThumbsDown className="h-5 w-5 mr-2" />
                  Not Satisfied
                </Button>
              </motion.div>
            </div>
            
            {feedbackGiven !== null && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="text-xs text-muted-foreground mt-3"
              >
                Feedback submitted. Thank you for helping us improve!
              </motion.p>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}