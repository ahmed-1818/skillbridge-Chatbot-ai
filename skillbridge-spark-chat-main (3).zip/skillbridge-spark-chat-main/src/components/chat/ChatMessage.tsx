import { motion } from 'framer-motion';
import { Bot, User } from 'lucide-react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

interface ChatMessageProps {
  message: {
    id: string;
    content: string;
    isUser: boolean;
    timestamp: Date;
  };
  index: number;
}

export function ChatMessage({ message, index }: ChatMessageProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.1 }}
      className={`flex items-start space-x-4 mb-6 ${
        message.isUser ? 'flex-row-reverse space-x-reverse' : ''
      }`}
    >
      <Avatar className={`${
        message.isUser 
          ? 'bg-gradient-primary text-primary-foreground' 
          : 'bg-muted text-muted-foreground'
      }`}>
        <AvatarFallback>
          {message.isUser ? (
            <User className="h-4 w-4" />
          ) : (
            <Bot className="h-4 w-4" />
          )}
        </AvatarFallback>
      </Avatar>

      <div className={`flex flex-col max-w-[70%] ${
        message.isUser ? 'items-end' : 'items-start'
      }`}>
        <div
          className={`rounded-2xl px-4 py-3 shadow-sm ${
            message.isUser
              ? 'bg-chat-user text-chat-user-foreground ml-auto'
              : 'bg-chat-bot text-chat-bot-foreground'
          }`}
        >
          <p className="text-sm leading-relaxed whitespace-pre-wrap">
            {message.content}
          </p>
        </div>
        
        <span className="text-xs text-muted-foreground mt-1 px-2">
          {message.timestamp.toLocaleTimeString([], { 
            hour: '2-digit', 
            minute: '2-digit' 
          })}
        </span>
      </div>
    </motion.div>
  );
}