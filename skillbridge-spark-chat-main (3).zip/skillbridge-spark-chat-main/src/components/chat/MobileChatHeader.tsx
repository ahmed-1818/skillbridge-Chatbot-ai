import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu, X } from 'lucide-react';
import { ChatSidebar } from './ChatSidebar';

interface MobileChatHeaderProps {
  user: { name: string; email: string };
  onLogout: () => void;
  chatHistory: Array<{ id: string; title: string; timestamp: Date }>;
  onSelectChat: (chatId: string) => void;
  escalationCount: number;
}

export function MobileChatHeader({
  user,
  onLogout,
  chatHistory,
  onSelectChat,
  escalationCount
}: MobileChatHeaderProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="md:hidden border-b border-border bg-background/80 backdrop-blur-sm p-4">
      <div className="flex items-center justify-between">
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-80">
            <ChatSidebar
              user={user}
              onLogout={onLogout}
              chatHistory={chatHistory}
              onSelectChat={(chatId) => {
                onSelectChat(chatId);
                setIsOpen(false);
              }}
              escalationCount={escalationCount}
            />
          </SheetContent>
        </Sheet>

        <div className="flex-1 text-center">
          <h2 className="text-lg font-semibold bg-gradient-primary bg-clip-text text-transparent">
            SkillBridge
          </h2>
        </div>

        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-success rounded-full"></div>
          <span className="text-xs text-muted-foreground">Online</span>
        </div>
      </div>
    </div>
  );
}