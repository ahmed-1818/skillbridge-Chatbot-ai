import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Send, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { FileUpload } from './FileUpload';

interface ChatInputProps {
  onSendMessage: (message: string, file?: File) => void;
  onEscalate: () => void;
  isLoading: boolean;
}

export function ChatInput({ onSendMessage, onEscalate, isLoading }: ChatInputProps) {
  const [message, setMessage] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !isLoading) {
      onSendMessage(message.trim(), selectedFile || undefined);
      setMessage('');
      setSelectedFile(null);
      
      // Reset textarea height
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleEscalate = () => {
    onEscalate();
    toast({
      title: "Escalated to Human Support",
      description: "A human agent will join this conversation soon.",
      className: "bg-accent text-accent-foreground",
    });
  };

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [message]);

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="border-t border-border bg-background/80 backdrop-blur-sm p-4"
    >
      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="flex items-end space-x-3">
          <div className="flex-1 space-y-2">
            {selectedFile && (
              <div className="px-2">
                <FileUpload 
                  onFileSelect={setSelectedFile}
                  selectedFile={selectedFile}
                  disabled={isLoading}
                />
              </div>
            )}
            <Textarea
              ref={textareaRef}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask about code, bugs, AI/ML, or tech development... (Press Enter to send)"
              className="min-h-[44px] max-h-32 resize-none bg-background/50 border-border focus:border-primary/50 focus:ring-primary/20"
              disabled={isLoading}
            />
          </div>
          
          <div className="flex space-x-2">
            {!selectedFile && (
              <FileUpload 
                onFileSelect={setSelectedFile}
                selectedFile={selectedFile}
                disabled={isLoading}
              />
            )}
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={handleEscalate}
              className="border-accent/50 text-accent hover:bg-accent/10 hover:border-accent"
              disabled={isLoading}
            >
              <AlertTriangle className="h-4 w-4" />
            </Button>
            
            <Button
              type="submit"
              size="icon"
              disabled={!message.trim() || isLoading}
              className="bg-gradient-primary hover:shadow-glow transition-all duration-300"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>
      </form>
      
      <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
        <span>Tech-focused AI • Files: ZIP, CSV, Images, PDF (max 10MB)</span>
        <span>{message.length}/1000</span>
      </div>
    </motion.div>
  );
}