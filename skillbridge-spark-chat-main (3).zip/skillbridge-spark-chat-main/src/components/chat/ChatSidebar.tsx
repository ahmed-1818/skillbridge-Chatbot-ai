import { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, Users, Settings, LogOut, Plus, HeadphonesIcon } from 'lucide-react';
import skillbridgeLogo from '@/assets/skillbridge-logo.png';

interface ChatSidebarProps {
  user: { name: string; email: string };
  onLogout: () => void;
  chatHistory: Array<{ id: string; title: string; timestamp: Date }>;
  onSelectChat: (chatId: string) => void;
  escalationCount: number;
}

export function ChatSidebar({ 
  user, 
  onLogout, 
  chatHistory, 
  onSelectChat, 
  escalationCount 
}: ChatSidebarProps) {
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);

  const handleSelectChat = (chatId: string) => {
    setSelectedChatId(chatId);
    onSelectChat(chatId);
  };

  const handleNewChat = () => {
    setSelectedChatId(null);
    onSelectChat('new');
  };

  return (
    <motion.aside
      initial={{ x: -300, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="w-80 bg-gradient-card border-r border-border flex flex-col h-screen hidden md:flex"
    >
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <img 
              src={skillbridgeLogo} 
              alt="SkillBridge AI" 
              className="w-24 h-6 object-contain"
            />
            <span className="text-sm font-medium bg-gradient-primary bg-clip-text text-transparent">
              AI
            </span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onLogout}
            className="text-muted-foreground hover:text-foreground"
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="flex items-center space-x-3 p-3 bg-background/50 rounded-lg">
          <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center text-primary-foreground font-medium text-sm">
            {user.name.charAt(0).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground truncate">
              {user.name}
            </p>
            <p className="text-xs text-muted-foreground truncate">
              {user.email}
            </p>
          </div>
        </div>
      </div>

      {/* New Chat Button */}
      <div className="p-4">
        <Button 
          onClick={handleNewChat}
          className="w-full bg-gradient-primary hover:shadow-glow transition-all duration-300"
        >
          <Plus className="h-4 w-4 mr-2" />
          New Chat
        </Button>
      </div>

      {/* Chat History */}
      <div className="flex-1 px-4">
        <h3 className="text-sm font-medium text-muted-foreground mb-3 flex items-center">
          <MessageSquare className="h-4 w-4 mr-2" />
          Recent Chats
        </h3>
        <ScrollArea className="h-full">
          <div className="space-y-2">
            {chatHistory.map((chat) => (
              <motion.button
                key={chat.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleSelectChat(chat.id)}
                className={`w-full text-left p-3 rounded-lg transition-all duration-200 ${
                  selectedChatId === chat.id
                    ? 'bg-primary/20 border border-primary/30'
                    : 'bg-background/30 hover:bg-background/50 border border-transparent'
                }`}
              >
                <p className="text-sm font-medium text-foreground truncate mb-1">
                  {chat.title}
                </p>
                <p className="text-xs text-muted-foreground">
                  {chat.timestamp.toLocaleDateString()}
                </p>
              </motion.button>
            ))}
            {chatHistory.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-8">
                No chat history yet. Start a new conversation!
              </p>
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Escalation Dashboard */}
      <div className="p-4 border-t border-border">
        <Card className="bg-background/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center justify-between">
              <span className="flex items-center">
                <HeadphonesIcon className="h-4 w-4 mr-2" />
                Support Center
              </span>
              {escalationCount > 0 && (
                <Badge variant="secondary" className="bg-accent text-accent-foreground">
                  {escalationCount}
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <p className="text-xs text-muted-foreground mb-3">
              {escalationCount > 0 
                ? `${escalationCount} pending escalation${escalationCount > 1 ? 's' : ''}`
                : 'No pending escalations'
              }
            </p>
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full border-accent/50 hover:bg-accent/10"
              onClick={() => window.location.href = '/freelancer-dashboard'}
            >
              <Users className="h-3 w-3 mr-2" />
              Freelancer Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    </motion.aside>
  );
}