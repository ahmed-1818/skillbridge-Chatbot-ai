from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import json
import datetime
import pandas as pd
from dotenv import load_dotenv
from langchain.vectorstores import FAISS
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.docstore.document import Document
from langchain.text_splitter import CharacterTextSplitter
from langchain.prompts import PromptTemplate
from langchain.chains import RetrievalQA
from langchain_groq import ChatGroq
import hashlib

# Load environment variables
load_dotenv()

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend integration

# ====================== Constants ======================
USERS_FILE = "data/users.json"
CHATS_FILE = "data/chats.json"
ESCALATION_LOG = "data/escalated_queries.csv"
FEEDBACK_FILE = "data/feedback.csv"

# Create data directory if it doesn't exist
os.makedirs("data", exist_ok=True)

# ====================== User Auth ======================
def load_users():
    if not os.path.exists(USERS_FILE):
        return {}
    with open(USERS_FILE, "r") as f:
        return json.load(f)

def save_users(users):
    with open(USERS_FILE, "w") as f:
        json.dump(users, f, indent=4)

def load_chats():
    if not os.path.exists(CHATS_FILE):
        return {}
    with open(CHATS_FILE, "r") as f:
        return json.load(f)

def save_chats(chats):
    with open(CHATS_FILE, "w") as f:
        json.dump(chats, f, indent=4)

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# ====================== API Routes ======================
@app.route('/api/signup', methods=['POST'])
def signup():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    name = data.get('name')
    
    if not email or not password or not name:
        return jsonify({'success': False, 'message': 'All fields required'}), 400
    
    users = load_users()
    if email in users:
        return jsonify({'success': False, 'message': 'User already exists'}), 400
    
    users[email] = {
        'password': hash_password(password),
        'name': name,
        'created_at': datetime.datetime.now().isoformat()
    }
    save_users(users)
    
    return jsonify({
        'success': True, 
        'user': {'email': email, 'name': name}
    })

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    
    if not email or not password:
        return jsonify({'success': False, 'message': 'Email and password required'}), 400
    
    users = load_users()
    if email in users and users[email]['password'] == hash_password(password):
        return jsonify({
            'success': True,
            'user': {'email': email, 'name': users[email]['name']}
        })
    
    return jsonify({'success': False, 'message': 'Invalid credentials'}), 401

# ====================== Chatbot Setup ======================
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

if GROQ_API_KEY:
    llm = ChatGroq(api_key=GROQ_API_KEY, model_name="llama3-8b-8192")
    
    skillbridge_docs = [
        "Welcome to SkillBridge – your smart freelance marketplace.",
        "Clients can post jobs and receive proposals from freelancers.",
        "Freelancers build profiles showcasing skills, portfolios, and pricing.",
        "SkillBridge supports project negotiation, milestone tracking, and secure payments.",
        "Clients and freelancers can chat to finalize job scope and pricing.",
        "Escalations are handled by human agents who respond within 24 hours.",
        "SkillBridge does not allow off-platform payments to ensure security.",
        "Ask technical questions about code, bugs, Python, JS, etc."
    ]
    
    documents = [Document(page_content=t) for t in skillbridge_docs]
    text_splitter = CharacterTextSplitter(chunk_size=300, chunk_overlap=50)
    docs = text_splitter.split_documents(documents)
    embedding = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    db = FAISS.from_documents(docs, embedding)
    retriever = db.as_retriever()
    
    prompt_template = PromptTemplate(
        input_variables=["context", "question"],
        template="""
You are SkillBridge's smart assistant.
Use the context below to answer user questions. If context doesn't help, use your own knowledge.

Context:
{context}

Question:
{question}

Answer:
"""
    )
    qa_chain = RetrievalQA.from_chain_type(llm=llm, retriever=retriever, chain_type_kwargs={"prompt": prompt_template})
else:
    qa_chain = None

def is_tech_related(prompt):
    """Filter for tech-related queries only"""
    tech_keywords = [
        'code', 'programming', 'python', 'javascript', 'react', 'nodejs', 'sql', 'database',
        'bug', 'error', 'debug', 'api', 'html', 'css', 'algorithm', 'data structure',
        'machine learning', 'ai', 'artificial intelligence', 'ml', 'deep learning',
        'computer vision', 'nlp', 'natural language processing', 'tensorflow', 'pytorch',
        'docker', 'kubernetes', 'devops', 'aws', 'cloud', 'server', 'deployment',
        'git', 'github', 'version control', 'framework', 'library', 'package',
        'function', 'variable', 'loop', 'array', 'object', 'class', 'method',
        'frontend', 'backend', 'fullstack', 'web development', 'mobile', 'app',
        'syntax', 'compile', 'runtime', 'exception', 'stack trace', 'performance'
    ]
    
    # Convert to lowercase for matching
    prompt_lower = prompt.lower()
    
    # Check if any tech keywords are present
    for keyword in tech_keywords:
        if keyword in prompt_lower:
            return True
    
    # Additional pattern matching for common tech scenarios
    tech_patterns = ['how to', 'why does', 'error:', 'exception:', 'not working', 'implement', 'optimize']
    for pattern in tech_patterns:
        if pattern in prompt_lower:
            # If pattern exists, check for some tech context
            for keyword in tech_keywords[:20]:  # Check first 20 most common tech terms
                if keyword in prompt_lower:
                    return True
    
    return False

def query_chatbot(prompt):
    if not qa_chain:
        return "Please set your GROQ_API_KEY in the .env file to enable AI responses."
    
    # Filter non-tech queries
    if not is_tech_related(prompt):
        return "SkillBridge only answers tech-related questions about programming, debugging, AI/ML, and technical development. Please refine your query to focus on technical topics."
    
    try:
        return qa_chain.run(prompt)
    except Exception as e:
        return f"Error generating response: {str(e)}"

@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.get_json()
    message = data.get('message')
    user_email = data.get('user_email')
    file_attached = data.get('file_attached', False)
    
    if not message or not user_email:
        return jsonify({'success': False, 'message': 'Message and user email required'}), 400
    
    # Get AI response
    ai_response = query_chatbot(message)
    
    # Save chat history
    chats = load_chats()
    if user_email not in chats:
        chats[user_email] = []
    
    chat_entry = {
        'id': len(chats[user_email]) + 1,
        'user_message': message,
        'ai_response': ai_response,
        'file_attached': file_attached,
        'timestamp': datetime.datetime.now().isoformat()
    }
    
    chats[user_email].append(chat_entry)
    save_chats(chats)
    
    # Log query for freelancer dashboard (auto-add to queries collection)
    log_query_for_freelancers(user_email, message, file_attached)
    
    return jsonify({
        'success': True,
        'response': ai_response,
        'timestamp': chat_entry['timestamp']
    })

def log_query_for_freelancers(user_email, question, file_attached=False):
    """Log all chat queries for freelancer view"""
    try:
        queries_file = "data/freelancer_queries.json"
        
        # Load existing queries
        if os.path.exists(queries_file):
            with open(queries_file, "r") as f:
                queries = json.load(f)
        else:
            queries = []
        
        # Get user name
        users = load_users()
        user_name = users.get(user_email, {}).get('name', 'Unknown User')
        
        # Create new query entry
        new_query = {
            'id': len(queries) + 1,
            'userId': user_email,
            'userName': user_name,
            'question': question,
            'fileAttached': file_attached,
            'time': datetime.datetime.now().isoformat(),
            'status': 'open',
            'escalated': False,
            'claimedBy': None,
            'bidPrice': None,
            'bidComment': None
        }
        
        queries.append(new_query)
        
        # Save queries
        with open(queries_file, "w") as f:
            json.dump(queries, f, indent=4)
            
    except Exception as e:
        print(f"Error logging query for freelancers: {e}")

@app.route('/api/freelancer-queries', methods=['GET'])
def get_freelancer_queries():
    """Get all queries for freelancer dashboard"""
    try:
        queries_file = "data/freelancer_queries.json"
        if not os.path.exists(queries_file):
            return jsonify({'success': True, 'queries': []})
            
        with open(queries_file, "r") as f:
            queries = json.load(f)
            
        return jsonify({'success': True, 'queries': queries})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/claim-query', methods=['POST'])
def claim_query():
    """Freelancer claims/bids on a query"""
    try:
        data = request.get_json()
        query_id = data.get('query_id')
        freelancer_email = data.get('freelancer_email')
        freelancer_name = data.get('freelancer_name')
        bid_price = data.get('bid_price')
        bid_comment = data.get('bid_comment', '')
        
        if not all([query_id, freelancer_email, freelancer_name]):
            return jsonify({'success': False, 'message': 'Missing required fields'}), 400
            
        queries_file = "data/freelancer_queries.json"
        if not os.path.exists(queries_file):
            return jsonify({'success': False, 'message': 'No queries found'}), 404
            
        with open(queries_file, "r") as f:
            queries = json.load(f)
            
        # Find and update the query
        for query in queries:
            if query['id'] == query_id:
                query['status'] = 'claimed'
                query['claimedBy'] = freelancer_name
                query['claimedByEmail'] = freelancer_email
                query['bidPrice'] = bid_price
                query['bidComment'] = bid_comment
                query['claimedAt'] = datetime.datetime.now().isoformat()
                break
        else:
            return jsonify({'success': False, 'message': 'Query not found'}), 404
            
        # Save updated queries
        with open(queries_file, "w") as f:
            json.dump(queries, f, indent=4)
            
        return jsonify({'success': True, 'message': 'Query claimed successfully'})
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/escalate', methods=['POST'])
def escalate():
    data = request.get_json()
    user_email = data.get('user_email')
    message = data.get('message', 'User requested escalation')
    
    if not user_email:
        return jsonify({'success': False, 'message': 'User email required'}), 400
    
    # Get user name
    users = load_users()
    user_name = users.get(user_email, {}).get('name', 'Unknown User')
    
    # Load existing escalations
    escalations = load_escalations()
    
    # Create new escalation
    new_escalation = {
        'id': len(escalations) + 1,
        'user_email': user_email,
        'user_name': user_name,
        'message': message,
        'status': 'pending',
        'priority': 'medium',
        'assigned_freelancer': None,
        'created_at': datetime.datetime.now().isoformat(),
        'resolved_at': None
    }
    
    escalations.append(new_escalation)
    save_escalations(escalations)
    
    # Also log to CSV for backward compatibility
    time_now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    df = pd.DataFrame([{
        'timestamp': time_now, 
        'user_email': user_email,
        'user_query': message, 
        'assigned': 'None'
    }])
    df.to_csv(ESCALATION_LOG, mode='a', header=not os.path.exists(ESCALATION_LOG), index=False)
    
    return jsonify({
        'success': True,
        'message': 'Your request has been escalated to our human support team.'
    })

@app.route('/api/feedback', methods=['POST'])
def feedback():
    data = request.get_json()
    user_email = data.get('user_email')
    satisfied = data.get('satisfied')
    
    if not user_email or satisfied is None:
        return jsonify({'success': False, 'message': 'User email and satisfaction required'}), 400
    
    # Save feedback
    df = pd.DataFrame([{
        'user_email': user_email, 
        'satisfied': satisfied,
        'timestamp': datetime.datetime.now().isoformat()
    }])
    df.to_csv(FEEDBACK_FILE, mode='a', header=not os.path.exists(FEEDBACK_FILE), index=False)
    
    return jsonify({'success': True, 'message': 'Feedback saved'})

@app.route('/api/chat-history/<user_email>', methods=['GET'])
def get_chat_history(user_email):
    chats = load_chats()
    user_chats = chats.get(user_email, [])
    return jsonify({'success': True, 'chats': user_chats})

# ====================== Freelancer Management ======================
def load_freelancers():
    freelancers_file = "data/freelancers.json"
    if not os.path.exists(freelancers_file):
        # Create sample freelancers
        sample_freelancers = [
            {
                "name": "John Smith",
                "email": "john@example.com",
                "skills": ["JavaScript", "React", "Node.js"],
                "rating": 4.8,
                "completed_tasks": 25,
                "hourly_rate": 45.0,
                "bio": "Full-stack developer with 5+ years experience"
            },
            {
                "name": "Sarah Johnson", 
                "email": "sarah@example.com",
                "skills": ["Python", "Django", "Data Science"],
                "rating": 4.9,
                "completed_tasks": 30,
                "hourly_rate": 50.0,
                "bio": "Data scientist and backend developer"
            },
            {
                "name": "Mike Chen",
                "email": "mike@example.com", 
                "skills": ["Full Stack", "DevOps", "AWS"],
                "rating": 4.7,
                "completed_tasks": 20,
                "hourly_rate": 40.0,
                "bio": "DevOps engineer and cloud architect"
            },
            {
                "name": "Emma Davis",
                "email": "emma@example.com",
                "skills": ["UI/UX", "Frontend", "Design"],
                "rating": 4.6,
                "completed_tasks": 18,
                "hourly_rate": 35.0,
                "bio": "UI/UX designer and frontend specialist"
            },
            {
                "name": "Alex Rodriguez",
                "email": "alex@example.com",
                "skills": ["Mobile", "React Native", "Flutter"],
                "rating": 4.8,
                "completed_tasks": 22,
                "hourly_rate": 42.0,
                "bio": "Mobile app developer"
            }
        ]
        with open(freelancers_file, "w") as f:
            json.dump(sample_freelancers, f, indent=4)
        return sample_freelancers
    
    with open(freelancers_file, "r") as f:
        return json.load(f)

def load_escalations():
    escalations_file = "data/escalations.json"
    if not os.path.exists(escalations_file):
        return []
    with open(escalations_file, "r") as f:
        return json.load(f)

def save_escalations(escalations):
    with open(escalations_file, "w") as f:
        json.dump(escalations, f, indent=4)

def load_bids():
    bids_file = "data/bids.json"
    if not os.path.exists(bids_file):
        return []
    with open(bids_file, "r") as f:
        return json.load(f)

def save_bids(bids):
    with open("data/bids.json", "w") as f:
        json.dump(bids, f, indent=4)

@app.route('/api/freelancers', methods=['GET'])
def get_freelancers():
    try:
        freelancers = load_freelancers()
        return jsonify({'success': True, 'freelancers': freelancers})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/escalated-queries', methods=['GET'])
def get_escalated_queries():
    try:
        escalations = load_escalations()
        return jsonify({'success': True, 'queries': escalations})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/bid', methods=['POST'])
def place_bid():
    try:
        data = request.get_json()
        escalation_id = data.get('escalation_id')
        freelancer_email = data.get('freelancer_email')
        freelancer_name = data.get('freelancer_name')
        bid_amount = data.get('bid_amount')
        message = data.get('message', '')
        
        bids = load_bids()
        new_bid = {
            'id': len(bids) + 1,
            'escalation_id': escalation_id,
            'freelancer_email': freelancer_email,
            'freelancer_name': freelancer_name,
            'bid_amount': bid_amount,
            'message': message,
            'status': 'pending',
            'created_at': datetime.datetime.now().isoformat()
        }
        
        bids.append(new_bid)
        save_bids(bids)
        
        return jsonify({'success': True, 'message': 'Bid placed successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/assign', methods=['POST'])
def assign_freelancer():
    try:
        data = request.get_json()
        escalation_id = data.get('escalation_id')
        freelancer_email = data.get('freelancer_email')
        
        escalations = load_escalations()
        for escalation in escalations:
            if escalation['id'] == escalation_id:
                escalation['status'] = 'assigned'
                escalation['assigned_freelancer'] = freelancer_email
                break
        
        save_escalations(escalations)
        
        # Update bid status
        bids = load_bids()
        for bid in bids:
            if bid['escalation_id'] == escalation_id and bid['freelancer_email'] == freelancer_email:
                bid['status'] = 'accepted'
                break
        save_bids(bids)
        
        return jsonify({'success': True, 'message': 'Freelancer assigned successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/stats', methods=['GET'])
def get_stats():
    try:
        # Count total chats
        chats = load_chats()
        total_chats = sum(len(user_chats) for user_chats in chats.values())
        
        # Count escalations
        escalations = load_escalations()
        total_escalations = len(escalations)
        resolved_escalations = len([e for e in escalations if e.get('status') == 'resolved'])
        
        # Get feedback stats
        feedback_data = []
        if os.path.exists(FEEDBACK_FILE):
            df = pd.read_csv(FEEDBACK_FILE)
            total_feedback = len(df)
            positive_feedback = len(df[df['satisfied'] == True]) if total_feedback > 0 else 0
            satisfaction_rate = (positive_feedback / total_feedback * 100) if total_feedback > 0 else 0
        else:
            total_feedback = 0
            satisfaction_rate = 0
        
        return jsonify({
            'success': True,
            'stats': {
                'total_chats': total_chats,
                'total_escalations': total_escalations,
                'resolved_escalations': resolved_escalations,
                'satisfaction_rate': satisfaction_rate,
                'total_users': len(load_users()),
                'total_freelancers': len(load_freelancers())
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({
        'status': 'healthy',
        'groq_configured': GROQ_API_KEY is not None,
        'timestamp': datetime.datetime.now().isoformat()
    })

if __name__ == '__main__':
    print("🚀 SkillBridge Backend Starting...")
    print("📡 Frontend can connect to: http://localhost:5000")
    if not GROQ_API_KEY:
        print("⚠️  Warning: GROQ_API_KEY not set. AI responses will be limited.")
    app.run(debug=True, port=5000)