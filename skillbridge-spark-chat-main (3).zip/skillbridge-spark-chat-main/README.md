# SkillBridge - AI-Powered Learning Assistant Platform

A modern web application connecting users with AI assistance and expert freelancers for skill development and learning support.

## 🏗️ Project Structure

### Frontend (React + TypeScript + Vite)

```
src/
├── components/           # Reusable UI components
│   ├── ui/              # Shadcn UI components
│   │   ├── button.tsx
│   │   ├── card.tsx
│   │   ├── dialog.tsx
│   │   ├── input.tsx
│   │   ├── textarea.tsx
│   │   ├── toast.tsx
│   │   └── ... (other UI components)
│   ├── auth/            # Authentication components
│   │   ├── LoginForm.tsx
│   │   └── SignupForm.tsx
│   ├── chat/            # Chat interface components
│   │   ├── ChatInput.tsx
│   │   ├── ChatMessage.tsx
│   │   ├── ChatSidebar.tsx
│   │   ├── FeedbackButtons.tsx
│   │   └── MobileChatHeader.tsx
│   └── support/         # Support dashboard components
│       ├── SupportHeader.tsx
│       ├── QueryCard.tsx
│       ├── FreelancerCard.tsx
│       ├── ProfileDialog.tsx
│       └── QueryDialog.tsx
├── pages/               # Main application pages
│   ├── Auth.tsx         # Authentication page
│   ├── Chat.tsx         # Main chat interface
│   ├── SupportDashboard.tsx    # Support team dashboard
│   ├── FreelancerDashboard.tsx # Freelancer dashboard
│   ├── AdminDashboard.tsx      # Admin dashboard
│   ├── Index.tsx        # Landing page
│   └── NotFound.tsx     # 404 page
├── hooks/               # Custom React hooks
│   ├── use-mobile.tsx
│   └── use-toast.ts
├── lib/                 # Utility libraries
│   └── utils.ts
├── assets/              # Static assets
│   └── skillbridge-hero.jpg
├── App.tsx              # Main app component with routing
├── main.tsx             # App entry point
├── index.css            # Global styles and design tokens
└── vite-env.d.ts        # TypeScript environment definitions
```

### Backend (Python Flask)

```
backend/
├── app.py               # Main Flask application
├── requirements.txt     # Python dependencies
├── .env.example         # Environment variables template
└── README.md            # Backend documentation
```

### Configuration Files

```
├── index.html           # HTML entry point
├── tailwind.config.ts   # Tailwind CSS configuration
├── vite.config.ts       # Vite configuration
├── eslint.config.js     # ESLint configuration
├── tsconfig.json        # TypeScript configuration
├── tsconfig.app.json    # App-specific TypeScript config
├── tsconfig.node.json   # Node-specific TypeScript config
├── postcss.config.js    # PostCSS configuration
├── components.json      # Shadcn UI configuration
├── package.json         # Node.js dependencies
├── package-lock.json    # Lock file for dependencies
└── bun.lockb            # Bun lock file
```

### Public Assets

```
public/
├── favicon.ico          # Website favicon
├── robots.txt           # SEO robots file
└── placeholder.svg      # Placeholder image
```

## 🚀 Getting Started

### Frontend Setup

1. **Install dependencies:**
   ```bash
   npm install
   # or
   bun install
   ```

2. **Start development server:**
   ```bash
   npm run dev
   # or
   bun run dev
   ```

3. **Build for production:**
   ```bash
   npm run build
   # or
   bun run build
   ```

### Backend Setup

1. **Navigate to backend directory:**
   ```bash
   cd backend
   ```

2. **Install Python dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Set up environment variables:**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

4. **Start Flask server:**
   ```bash
   python app.py
   ```

## 🏛️ Architecture Overview

### Frontend Architecture

- **React 18** with TypeScript for type-safe development
- **Vite** for fast development and optimized builds
- **Tailwind CSS** with custom design system tokens
- **Shadcn UI** for consistent, accessible components
- **React Router** for client-side routing
- **Framer Motion** for smooth animations
- **React Query** for server state management

### Key Features

1. **Multi-Dashboard System:**
   - **Chat Interface:** Main AI-powered chat for learning assistance
   - **Support Dashboard:** For support team to manage escalated queries
   - **Freelancer Dashboard:** For freelancers to bid on and manage queries
   - **Admin Dashboard:** For administrators to oversee the platform

2. **Authentication System:**
   - Login/Signup forms with form validation
   - Persistent user sessions with localStorage
   - Protected routes with automatic redirects

3. **Real-time Chat Interface:**
   - Message threading and conversation history
   - File upload capabilities
   - Responsive design for mobile and desktop

4. **Query Management System:**
   - Query escalation from chat to human experts
   - Bidding system for freelancers
   - Status tracking and priority management

### Design System

The application uses a comprehensive design system defined in:
- `src/index.css` - CSS custom properties and design tokens
- `tailwind.config.ts` - Tailwind configuration with semantic color system
- All colors use HSL format for consistent theming
- Dark/light mode support throughout

### Component Organization

- **UI Components:** Reusable, unstyled base components from Shadcn
- **Feature Components:** Business logic components organized by feature
- **Page Components:** Top-level route components
- **Custom Hooks:** Shared logic and state management

## 🔧 Development Workflow

### File Viewing Sequence for Development

**Main Application Flow:**
1. `src/main.tsx` → App entry point
2. `src/App.tsx` → Routing and authentication logic
3. `src/pages/Auth.tsx` → Login/signup flow
4. `src/pages/Chat.tsx` → Main chat interface
5. `src/pages/SupportDashboard.tsx` → Support team interface
6. `src/pages/FreelancerDashboard.tsx` → Freelancer interface
7. `src/pages/AdminDashboard.tsx` → Admin interface

**Component Architecture:**
1. `src/components/ui/` → Base UI components (buttons, inputs, etc.)
2. `src/components/auth/` → Authentication forms
3. `src/components/chat/` → Chat interface components
4. `src/components/support/` → Support dashboard components

**Styling System:**
1. `src/index.css` → Design tokens and global styles
2. `tailwind.config.ts` → Tailwind configuration
3. Individual component files → Component-specific styles

**Backend:**
1. `backend/app.py` → Flask server and API endpoints
2. `backend/requirements.txt` → Python dependencies
3. `backend/.env.example` → Environment variables template

### Adding New Features

1. Create components in appropriate feature folders
2. Update routing in `App.tsx` if needed
3. Add any new UI components to `src/components/ui/`
4. Update design tokens in `index.css` as needed

### Backend Integration

- API endpoints defined in `backend/app.py`
- Frontend API calls use axios (installed but not fully integrated)
- Mock data currently used for development

## 📝 Current Status

- ✅ Frontend fully functional with mock data
- ✅ Multi-dashboard navigation working
- ✅ Authentication flow implemented
- ✅ Chat interface operational
- ✅ Component architecture properly organized
- 🔄 Backend API integration pending
- 🔄 Real-time features to be implemented

## 🚀 Deployment Options

### Lovable Platform (Recommended)
Simply open [Lovable](https://lovable.dev/projects/f355f7ec-e73a-4d68-80bd-d6f9e30f2a37) and click on Share → Publish.

### Custom Deployment
1. Build the frontend: `npm run build`
2. Serve the `dist/` folder with any static file server
3. Deploy the backend Flask app to your preferred Python hosting service
4. Update API endpoints in frontend to match your backend deployment

## 🔗 Custom Domain

To connect a domain, navigate to Project > Settings > Domains and click Connect Domain.
Read more: [Setting up a custom domain](https://docs.lovable.dev/tips-tricks/custom-domain#step-by-step-guide)

## 🤝 Contributing

1. Follow the existing file structure and naming conventions
2. Use TypeScript for all new components
3. Implement responsive design using Tailwind utilities
4. Use semantic design tokens instead of direct colors
5. Keep components focused and single-responsibility
6. Add proper error handling and loading states

---

**Tech Stack:** React 18, TypeScript, Vite, Tailwind CSS, Shadcn UI, Flask, Python
